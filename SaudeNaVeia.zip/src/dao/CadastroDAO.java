package dao;

import beans.Cadastro;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * @author keijo
 */
public class CadastroDAO {
    private Conexao conexao;
    private Connection conn;
    
    public Cadastro DAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
        return null;
    }
    public void inserir(Cadastro cadastro){
        String sql = "INSERT INTO cadastro (nome,usuario,senha,email) VALUES (?,?,?,?)";
        try{
            PreparedStatement stmt =this.conn.prepareStatement(sql);
            stmt.setString(1, cadastro.getNome());
            stmt.setString(2, cadastro.getUsuario());
            stmt.setString(3, cadastro.getSenha());
            stmt.setString(4, cadastro.getEmail());
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao inserir produto: "+ e.getMessage());
        }
    }
}
