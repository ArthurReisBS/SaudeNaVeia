package dao;

import beans.CadastroProfissional;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * @author keijo
 */
public class CadastroProfissionalDAO {
    private Conexao conexao;
    private Connection conn;
    
    public CadastroProfissional DAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
        return null;
    }
    public void inserir(CadastroProfissional cadastro){
        String sql = "INSERT INTO cadastroprofissional (nome,usuario,senha,email) VALUES (?,?,?,?)";
        try{
            PreparedStatement stmt =this.conn.prepareStatement(sql);
            stmt.setString(1, cadastro.getNome());
            stmt.setString(2, cadastro.getUsuario());
            stmt.setString(3, cadastro.getSenha());
            stmt.setString(4, cadastro.getEmail());
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao inserir produto: "+ e.getMessage());
        }
    }
}
